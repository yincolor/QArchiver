#ifndef __OBJECT_H__
#define __OBJECT_H__

struct object;

typedef struct object{
    void *data; // 对象指针
    size_t mem_size; // 内存长度
    void (*destroy)(Object *self); // 销毁对象函数
    void (*fill_test_byte)(Object *self);
} Object;

Object *create_object(size_t mem_size);
static void object_destroy(Object *self); 
static void object_fill_test_byte(Object *self);
#endif